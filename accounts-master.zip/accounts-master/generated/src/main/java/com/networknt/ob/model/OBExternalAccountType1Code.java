
package com.networknt.ob.model;
import java.util.Enumeration;

public enum OBExternalAccountType1Code {
    Business, Personal;

}
