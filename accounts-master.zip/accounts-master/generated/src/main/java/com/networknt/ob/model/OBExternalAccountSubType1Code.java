
package com.networknt.ob.model;
import java.util.Enumeration;

public enum OBExternalAccountSubType1Code {
    ChargeCard, CreditCard, CurrentAccount, EMoney, Loan, Mortgage, PrePaidCard, Savings;

}
